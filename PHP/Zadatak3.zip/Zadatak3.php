<?php
//klase se pisu velikoim slovom
//neki konstruktor klase kao u javi
/*class Covjek {
	public $ime;
	public $prezime;
	public $godine;
	
	public function ispisGodina() {
		echo($this->godine)."</br>";
	}
}


//zatim instanciranje varijable klase Covjek
$covjek=new Covjek;

//pa dodjela vrijednosti varijablama covjek
//ova -> je zapravo kao . u javi covjek.ime="ivan";

$covjek->ime="Ivan";
$covjek->prezime="Juki";
$covjek->godine="28";

$covjek->ispisGodina();
*/

class Kocka {
	public $duljina;
	public $visina;
	public $sirina;
	
	public function ispis_dimenzija() {
		echo ($this->duljina)."x".($this->visina)."x".($this->sirina)."</br>";
	}
}

$kocka1 = new Kocka;
$kocka1->duljina="11";
$kocka1->visina="32";
$kocka1->sirina="13";

$kocka2 = new Kocka;
$kocka2->duljina="10";
$kocka2->visina="20";
$kocka2->sirina="10";

$kocka1->ispis_dimenzija();
$kocka2->ispis_dimenzija();

echo usporedi_volumen($kocka1, $kocka2);


function usporedi_volumen($kocka1, $kocka2){
	$volumen1=($kocka1->visina)*($kocka1->sirina)*($kocka1->duljina);
	
	$volumen2=($kocka2->visina)*($kocka2->sirina)*($kocka2->duljina);
	
	
	if ($volumen1>$volumen2) {
		return $volumen1;
	} else {
		return $volumen2;
	}
	
}


?>