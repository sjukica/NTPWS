<?php

//prjie svega moram otici na xampp contoler i tamo kliknui na Admin pokraj MySql..onda mi se otvori preko browsera phpMyAdmin..odem na tab Database i zatiom na Cretadatabase (normalo da pazim da ime database koje sam kreirao mi odogovara database_name nize navedeno)..odabirem Collation (to ima neke veze za nacinom fizickog zapsia database)

$database_host="localhost"; //host baze
$database_name="xmlapp"; //
$database_username="root";
$database_password=""; //lozinku ostavim praznu

//Nakon toga instancimako objekt koji sadrzi konekcoju na bazu
$database_connection= new MySQLi($database_host, $database_username, $database_password, $database_name);

//Pa provjerimo je li konekcija uspjesno prosla

if (mysqli_connect_errno()){
	echo("Database konekcija nije prosla");
	die;
} else {
	echo("Povezalo se");
}

/*ovdje je ocito obicaj da upit spremis u varijabblu pa onda tu varijablu bascis u funkciju. Jedini problem s ovim upitom je što je moguće vrlo lako napraviti // SQL injection napad tj. napisati umjesto “naziv” neki upit koji će obrisati cijelu tablicu.
//upit = "INSERT INTO cars VALUES (1,\"naziv\",\"plavi\",250,4);";
//ovo je priprema upita

//Upit moramo sanitarizirati (engl. sanitize). Tu ćemo iskoristiti i onu treću verziju INSERT INTO naredbe.
//$upit = "INSERT INTO cars SET (id, name, color, max_speed, number_of_seats) VALUES (?,?,?,?,?);";*/

//Nakon toga radimo prepare naredbe:
$sql="INSERT INTO cars (id, name, color, max_speed, number_of_seats) VALUES (1,'ime', 'plava',23,4)";

if ($database_connection->query($sql)===TRUE){
	echo "Dodana je vrijednost";
} else {
	echo "nije uspjelo";
}




/*ovo issii znaci 
i	corresponding variable has type integer
d	corresponding variable has type double
s	corresponding variable has type string
b	corresponding variable is a blob and will be sent in packets
*/



?>