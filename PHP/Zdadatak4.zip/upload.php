<?php
if ( isset( $_FILES[ "file" ] ) ) {


	$currentDir = getcwd();
	$uploadDirectory = "/uploads/";

	$errors = array();
	$file_name = $_FILES[ "file" ][ "name" ];
	$file_size = $_FILES[ "file" ][ "size" ];
	$file_tmp = $_FILES[ "file" ][ "tmp_name" ];
	$file_type = $_FILES[ "file" ][ "type" ];
	$file_ext = strtolower( end( explode( '.', $_FILES[ "file" ][ "name" ] ) ) );

	$uploadPath = $currentDir . $uploadDirectory . basename($file_name); 
	
	$expensions = array( "jpeg", "jpg", "png" );

	if ( in_array( $file_ext, $expensions ) === false ) {
		$errors[] = "extension not allowed, please choose a JPEG or PNG file.";
	}

	if ( empty( $errors ) == true ) {
		move_uploaded_file($file_tmp, $uploadPath);
		echo "Success";
	} else {
		print_r( $errors );
	}
}
?>