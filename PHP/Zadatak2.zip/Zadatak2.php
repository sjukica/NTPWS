<?php

/*
function moj_uppercase ($string) {
	//prvo cemo provjerit jesmo li dobili prazan string pa ako je odmah ce vratit false
	if ($string != null) {
		$duljina_stringa = strlen($string);
		
		for ($i=0; $i<$duljina_stringa; $i++){
			$string[$i]=strtoupper($string[$i]);
		}
		return($string);
		
	}
	
	return false;
}
//a funkciju pozvimako kao i u Javi..ime_funckije argument koji joj saljem

echo moj_uppercase("dinamo!");

Postoji nekoliko vrsta include funkcija: include, include_once, require, require_once
Funkcije koje imaju _once u imenu će ubaciti datoteku samo jednom, bez obzira koliko puta napišemo tu
naredbu.
Razlika između include i require je što, ako datoteka ne postoji, include će ignorirati, a require će javiti
error.
*/

//ovo je funckija koja poziva drugu i salje joj dva string ana usporedbu

require("Zadatak2b.php");

echo(usporedba_stringova("jedan", "jedan"));
	?>