<?php

function usporedba_stringova ($string1, $string2) {
//pretpostavka je da ce dva stringa koja ulaze biti jednaki..funkcija zatim prolazi kroz slova i ako nisi jednaki jednakost stavlja FALSE i vraca false
//i odmah ako stringovi nisu jednake duljina funckija ce reci da nisu ista i vratiti FALSE
//zadatak kaze d atreba vratiti -1 ali ja sam narpavio sa 0 jer mi je logicnije
//funckija se obazire na velika i mala slova

	$jednakost = 1;
	$duljina_stringa1=strlen($string1);
	$duljina_stringa2=strlen($string2);
	if($duljina_stringa1!=$duljina_stringa2){
		$jednakost = 0;
		return $jednakost;
	}
	for ($i=0; $i<$duljina_stringa1; $i++){
		if ($string1[$i]!=$string2[$i]) {
			$jednakost = 0;
		}
		return $jednakost;
	}
}

?>